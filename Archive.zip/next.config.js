module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['images.pokemontcg.io', 'encrypted-tbn0.gstatic.com'],
  }
}
